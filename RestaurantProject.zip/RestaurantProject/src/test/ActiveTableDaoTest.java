package test;

import Dao.ActiveTableDao;
import TableModel.Table;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

public class ActiveTableDaoTest {

    @Test
    public void refreshTest() throws IOException, ClassNotFoundException {
        ActiveTableDao dao=new ActiveTableDao();
        dao.setPath("activeTables_test.txt");
        ArrayList<Table> myTables=dao.refreshActiveTables();

        for (int i=1;i<10;i++){
            Assertions.assertEquals(myTables.get(i-1).getTableNum(),i);
        }
    }

    @Test
    public void updateTest() throws IOException, ClassNotFoundException {
        Table table=new Table( 2, 1,true);
        ActiveTableDao dao=new ActiveTableDao();
        dao.setPath("activeTables_test.txt");

        dao.updateTable(table.getTableNum(), table);
        ArrayList<Table> myTables=dao.refreshActiveTables();
        Assertions.assertEquals(myTables.get(0).getTableNum(),1);
        Assertions.assertEquals(myTables.get(0).getStatus(),true);
        Assertions.assertEquals(myTables.get(0).getNum_of_diners(),2);
    }

    @Test
    public void updateFullActiveTableTest() throws IOException, ClassNotFoundException {
        ArrayList<Table> myTables=new ArrayList<>();
        for (int i=0;i<10;i++){
            myTables.add(new Table( 0, i+1,false));
        }

        ActiveTableDao dao=new ActiveTableDao();
        dao.setPath("activeTables_test.txt");

        dao.updateFullActiveTables(myTables);
        ArrayList<Table> myCheckTables= dao.refreshActiveTables();
        for (int i=0;i<10;i++){
            Assertions.assertEquals(myCheckTables.get(i).getTableNum(),i+1);
            Assertions.assertEquals(myCheckTables.get(i).getStatus(),false);
            Assertions.assertEquals(myCheckTables.get(i).getNum_of_diners(),0);
        }

    }



}

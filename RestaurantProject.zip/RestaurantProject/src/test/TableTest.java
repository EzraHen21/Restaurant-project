package test;

import TableModel.Food;
import TableModel.Payment;
import TableModel.Table;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class TableTest {

    @Test
    public void constructorTest(){
        Table table=new Table(10,1,true);
        Assertions.assertEquals(10,table.getNum_of_diners());
        Assertions.assertEquals(0,table.getTableId());
//        Assertions.assertEquals(1,IdForTables);

        Table table1=new Table();
        Assertions.assertEquals(0,table1.getNum_of_diners());
        Assertions.assertEquals(1,table1.getTableId());
//        Assertions.assertEquals(2,IdForTables);

        Table table2=new Table();
        Assertions.assertEquals(2,table2.getTableId());
    }

    @Test
    public void inviteTest(){
        Table table=new Table(4,1,true);
        Food f1= new Food( 100,"hamburger");
        table.inviteFood(f1);
        Assertions.assertEquals(f1,table.getFood_order().get(0));
        Assertions.assertEquals(100,table.getTotalAmount());
        Payment payment= table.getPayment();
        Assertions.assertEquals(100,payment.getTotal_amount());
    }

    @Test
    public void tableTojsonTest(){
        Table table=new Table(3,1,true);
        String json= table.tableTojson();
        System.out.println(json);
    }

    @Test
    public void tableIdTest(){
        ArrayList<Integer> countArray =new ArrayList<>();
        for (int i=0; i<105; i++)
        {
            countArray.add(0);
        }

        for (int i=0; i<100; i++){
            Thread thread= new Thread(new Runnable() {
                @Override
                public void run() {
                    Table table =new Table();
//                    System.out.println(table.getTableId());
                    countArray.set(table.getTableId(), countArray.get(table.getTableId())+1);
                }
            });
            thread.start();
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }



        for (int i=4; i<104; i++)
        {
            Assertions.assertEquals(countArray.get(i), 1);
            }
        }
    }


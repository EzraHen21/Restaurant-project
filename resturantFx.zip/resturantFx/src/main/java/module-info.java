module com.example.resturantfx {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires com.google.gson;
    requires java.base;

    opens com.example.resturantfx to javafx.fxml,com.google.gson, java.base;
    exports com.example.resturantfx;
    exports com.example.resturantfx.MyModels;
    opens com.example.resturantfx.MyModels to com.google.gson, java.base, javafx.fxml;
}